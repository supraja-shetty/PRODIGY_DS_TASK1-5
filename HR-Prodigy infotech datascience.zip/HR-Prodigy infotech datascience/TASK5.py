import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import folium
from folium.plugins import HeatMap
import random
from datetime import datetime, timedelta

# Step 1: Generate synthetic accident dataset
n_samples = 1000
np.random.seed(42)

data = {
    'datetime': [datetime(2024, 1, 1) + timedelta(hours=random.randint(0, 3000)) for _ in range(n_samples)],
    'weather': np.random.choice(['Clear', 'Rain', 'Fog', 'Snow', 'Cloudy'], size=n_samples, p=[0.5, 0.2, 0.1, 0.05, 0.15]),
    'road_condition': np.random.choice(['Dry', 'Wet', 'Icy'], size=n_samples, p=[0.6, 0.3, 0.1]),
    'severity': np.random.randint(1, 5, size=n_samples),
    'latitude': np.random.uniform(12.90, 13.10, size=n_samples),
    'longitude': np.random.uniform(77.50, 77.70, size=n_samples)
}

df = pd.DataFrame(data)
df['hour'] = df['datetime'].dt.hour
df['day'] = df['datetime'].dt.day_name()

# Step 2: Visualizations

# a. Accidents by time of day
plt.figure(figsize=(10, 5))
sns.countplot(x='hour', data=df, palette='coolwarm')
plt.title("Accidents by Hour of Day")
plt.xlabel("Hour")
plt.ylabel("Number of Accidents")
plt.xticks(rotation=45)
plt.grid(True)
plt.show()

# b. Weather vs Severity
plt.figure(figsize=(8, 5))
sns.boxplot(x='weather', y='severity', data=df)
plt.title("Accident Severity by Weather Condition")
plt.grid(True)
plt.show()

# c. Road condition vs Severity
plt.figure(figsize=(8, 5))
sns.violinplot(x='road_condition', y='severity', data=df)
plt.title("Accident Severity by Road Condition")
plt.grid(True)
plt.show()

# d. Heatmap of accident locations (optional: in HTML)
map_center = [df['latitude'].mean(), df['longitude'].mean()]
m = folium.Map(location=map_center, zoom_start=12)
HeatMap(data=df[['latitude', 'longitude']], radius=10).add_to(m)

# Save the heatmap as an HTML file
m.save("accident_hotspots_map.html")
print("🌍 Heatmap saved as 'accident_hotspots_map.html'")