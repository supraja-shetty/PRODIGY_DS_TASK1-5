import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Sample dataset
data = {
    "Person": range(1, 11),
    "Age": [22, 35, 28, 40, 31, 24, 30, 45, 52, 27],
    "Gender": ["Male", "Female", "Female", "Male", "Other", "Male", "Female", "Female", "Male", "Male"]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Create figure and axes
fig, axs = plt.subplots(1, 2, figsize=(12, 5))

# Bar chart: Gender distribution
sns.countplot(x="Gender", data=df, ax=axs[0], palette="pastel")
axs[0].set_title("Gender Distribution")
axs[0].set_ylabel("Count")

# Histogram: Age distribution
sns.histplot(df["Age"], bins=5, kde=False, ax=axs[1], color="skyblue", edgecolor="black")
axs[1].set_title("Age Distribution")
axs[1].set_xlabel("Age")
axs[1].set_ylabel("Frequency")

# Show plots
plt.tight_layout()
plt.show()