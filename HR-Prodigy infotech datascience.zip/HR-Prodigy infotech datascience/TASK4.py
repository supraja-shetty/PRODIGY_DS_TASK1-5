import pandas as pd
import numpy as np
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import random
import datetime

# Step 1: Create mock social media posts
topics = ['BrandA', 'BrandB']
positive_comments = ["Love it!", "Fantastic service", "Absolutely amazing", "So happy with it", "Would buy again"]
negative_comments = ["Terrible", "Worst experience", "I hate this", "Never again", "So bad"]
neutral_comments = ["Okay", "Fine", "It's just alright", "Nothing special", "Average"]

data = []
for _ in range(200):
    topic = random.choice(topics)
    sentiment = random.choices(["positive", "negative", "neutral"], weights=[0.4, 0.3, 0.3])[0]
    if sentiment == "positive":
        text = random.choice(positive_comments)
    elif sentiment == "negative":
        text = random.choice(negative_comments)
    else:
        text = random.choice(neutral_comments)
    
    date = datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 30))
    data.append([date, topic, text])

df = pd.DataFrame(data, columns=["date", "topic", "text"])

# Step 2: Sentiment analysis using TextBlob
df["polarity"] = df["text"].apply(lambda x: TextBlob(x).sentiment.polarity)
df["sentiment"] = df["polarity"].apply(lambda x: "positive" if x > 0.1 else ("negative" if x < -0.1 else "neutral"))

# Step 3: Sentiment distribution
plt.figure(figsize=(8, 5))
sns.countplot(x="sentiment", hue="topic", data=df, palette="pastel")
plt.title("Sentiment Distribution by Topic")
plt.show()

