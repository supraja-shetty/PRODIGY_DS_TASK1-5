import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load Titanic dataset
titanic = sns.load_dataset('titanic')

# 1. Basic Info
print("Basic Info:")
print(titanic.info())

# 2. Missing Values
print("\nMissing Values:")
print(titanic.isnull().sum().sort_values(ascending=False))

# 3. Summary Stats
print("\nSummary Statistics:")
print(titanic.describe(include='all'))

# 4. Data Cleaning
titanic_cleaned = titanic.copy()
titanic_cleaned.dropna(subset=['embarked'], inplace=True)
titanic_cleaned['age'].fillna(titanic_cleaned['age'].median(), inplace=True)
titanic_cleaned.drop(columns=['deck', 'embark_town', 'alive'], inplace=True)

# 5. Cleaned Data Info
print("\nCleaned Data Info:")
print(titanic_cleaned.info())

# 6. Exploratory Data Analysis (EDA) Plots

# a. Survival Count
sns.countplot(x='survived', data=titanic_cleaned)
plt.title('Survival Count')
plt.show()

# b. Survival by Sex
sns.countplot(x='sex', hue='survived', data=titanic_cleaned)
plt.title('Survival by Gender')
plt.show()

# c. Age Distribution
sns.histplot(titanic_cleaned['age'], bins=20, kde=True)
plt.title('Age Distribution')
plt.show()

# d. Fare by Class
sns.boxplot(x='pclass', y='fare', data=titanic_cleaned)
plt.title('Fare Distribution by Class')
plt.show()

# e. Correlation Heatmap
corr = titanic_cleaned[['age', 'fare', 'pclass', 'survived']].corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.show()