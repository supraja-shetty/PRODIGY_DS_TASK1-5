import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# Step 1: Generate synthetic data
np.random.seed(42)
n_samples = 1000

data = pd.DataFrame({
    'age': np.random.randint(18, 65, size=n_samples),
    'job': np.random.choice(['admin', 'technician', 'services', 'blue-collar', 'retired', 'student'], size=n_samples),
    'marital': np.random.choice(['married', 'single', 'divorced'], size=n_samples),
    'education': np.random.choice(['primary', 'secondary', 'tertiary'], size=n_samples),
    'balance': np.random.randint(-2000, 5000, size=n_samples),
    'housing': np.random.choice(['yes', 'no'], size=n_samples),
    'loan': np.random.choice(['yes', 'no'], size=n_samples),
    'contact': np.random.choice(['cellular', 'telephone'], size=n_samples),
    'day': np.random.randint(1, 31, size=n_samples),
    'duration': np.random.randint(10, 1800, size=n_samples),
    'campaign': np.random.randint(1, 10, size=n_samples),
    'pdays': np.random.randint(-1, 999, size=n_samples),
    'previous': np.random.randint(0, 5, size=n_samples),
    'poutcome': np.random.choice(['success', 'failure', 'unknown'], size=n_samples),
    'y': np.random.choice([0, 1], size=n_samples, p=[0.75, 0.25])  # Target: 1 means purchase
})

# Step 2: Encode categorical features
data_encoded = pd.get_dummies(data.drop('y', axis=1))
X = data_encoded
y = data['y']

# Step 3: Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 4: Decision Tree Model
clf = DecisionTreeClassifier(max_depth=5, random_state=42)
clf.fit(X_train, y_train)

# Step 5: Predictions
y_pred = clf.predict(X_test)

# Step 6: Evaluation
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# Step 7: Visualization
plt.figure(figsize=(20, 10))
plot_tree(clf, feature_names=X.columns, class_names=['No', 'Yes'], filled=True, rounded=True)
plt.title("Decision Tree - Product Purchase Prediction")
plt.show()